"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Calendar, ChevronLeft, ChevronRight } from "lucide-react"

// Remove this line:
// import { initialTreatments } from "./treatments-tab"

// Keep the import for professionals if you're still using it
import { initialProfessionals } from "./professionals-tab"

// Mock data for appointments
const initialAppointments = [
  {
    id: 1,
    date: "2025-03-03",
    time: "10:00",
    status: "reserved",
    professionalId: 1,
    professionalName: "María López",
    treatmentId: 1,
    treatmentName: "Limpieza Facial",
    clientId: 1,
    clientName: "Ana García",
    box: "Box 1",
    deposit: 2000,
    price: 5000,
    notes: "Primera sesión",
  },
  {
    id: 2,
    date: "2025-03-03",
    time: "11:30",
    status: "completed",
    professionalId: 2,
    professionalName: "Carlos Rodríguez",
    treatmentId: 3,
    treatmentName: "Masaje Relajante",
    clientId: 2,
    clientName: "Juan Pérez",
    box: "Box 2",
    deposit: 3000,
    price: 6000,
    notes: "",
  },
  {
    id: 3,
    date: "2025-03-03",
    time: "09:00",
    status: "available",
    professionalId: 3,
    professionalName: "Laura Fernández",
    treatmentId: null,
    treatmentName: null,
    clientId: null,
    clientName: null,
    box: "Box 3",
    deposit: 0,
    price: 0,
    notes: "",
  },
  {
    id: 4,
    date: "2025-03-03",
    time: "15:00",
    status: "cancelled",
    professionalId: 1,
    professionalName: "María López",
    treatmentId: 2,
    treatmentName: "Limpieza Facial Profunda",
    clientId: 3,
    clientName: "Sofía Martínez",
    box: "Box 1",
    deposit: 1000,
    price: 7500,
    notes: "Cancelado por el cliente",
  },
]

// Mock data for dropdowns
const professionals = [
  { id: 1, name: "María López" },
  { id: 2, name: "Carlos Rodríguez" },
  { id: 3, name: "Laura Fernández" },
]

const clients = [
  { id: 1, name: "Ana García" },
  { id: 2, name: "Juan Pérez" },
  { id: 3, name: "Sofía Martínez" },
]

const boxes = ["Box 1", "Box 2", "Box 3", "Box 4", "Box 5"]
const timeSlots = [
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "12:00",
  "12:30",
  "13:00",
  "13:30",
  "14:00",
  "14:30",
  "15:00",
  "15:30",
  "16:00",
  "16:30",
  "17:00",
  "17:30",
]

interface Appointment {
  id: number
  date: string
  time: string
  status: "available" | "reserved" | "completed" | "cancelled"
  professionalId: number
  professionalName: string
  treatmentId: number | null
  treatmentName: string | null
  clientId: number | null
  clientName: string | null
  box: string
  deposit: number
  price: number
  notes: string
}

export default function AgendaTab() {
  const [treatments, setTreatments] = useState([])
  const [appointments, setAppointments] = useState<Appointment[]>(initialAppointments)
  const [selectedDate, setSelectedDate] = useState<string>("2025-03-03")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [currentAppointment, setCurrentAppointment] = useState<Appointment | null>(null)
  const [formData, setFormData] = useState({
    date: "",
    time: "",
    status: "",
    professionalId: "",
    treatmentId: "",
    clientId: "",
    box: "",
    deposit: "",
    price: "",
    notes: "",
  })

  const [availableProfessionals, setAvailableProfessionals] = useState([])
  const [availableTreatments, setAvailableTreatments] = useState([])

  useEffect(() => {
    fetchTreatments()
  }, [])

  const fetchTreatments = async () => {
    try {
      const response = await fetch("/api/treatments")
      if (!response.ok) {
        throw new Error("Failed to fetch treatments")
      }
      const data = await response.json()
      setTreatments(data)
    } catch (error) {
      console.error("Error fetching treatments:", error)
    }
  }

  const updateAvailability = useCallback(() => {
    const date = new Date(selectedDate)
    const time = formData.time

    const availableProfs = initialProfessionals.filter((prof) => {
      const availStart = new Date(prof.availability.startDate)
      const availEnd = new Date(prof.availability.endDate)
      return (
        date >= availStart &&
        date <= availEnd &&
        time >= prof.availability.startTime &&
        time <= prof.availability.endTime
      )
    })

    const availableTreats = treatments.filter((treat) => {
      if (!treat.isSubtreatment || !treat.availability) return false
      return treat.availability.some((avail) => {
        const availStart = new Date(`${avail.startDate}T${avail.startTime}`)
        const availEnd = new Date(`${avail.endDate}T${avail.endTime}`)
        const currentDate = new Date(`${selectedDate}T${time}`)
        return currentDate >= availStart && currentDate <= availEnd && time >= avail.startTime && time <= avail.endTime
      })
    })

    setAvailableProfessionals(availableProfs)
    setAvailableTreatments(availableTreats)
  }, [selectedDate, formData.time, treatments])

  useEffect(() => {
    updateAvailability()
  }, [updateAvailability])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleSelectChange = (name: string, value: string) => {
    if (name === "treatmentId" && value) {
      const selectedTreatment = treatments.find((t) => t.id.toString() === value)
      if (selectedTreatment) {
        setFormData({
          ...formData,
          [name]: value,
          price: selectedTreatment.price.toString(),
        })
        return
      }
    }
    setFormData({ ...formData, [name]: value })
  }

  const resetForm = () => {
    setFormData({
      date: selectedDate,
      time: "09:00",
      status: "available",
      professionalId: "",
      treatmentId: "",
      clientId: "",
      box: "Box 1",
      deposit: "0",
      price: "0",
      notes: "",
    })
  }

  const handleOpenDialog = (appointment: Appointment | null = null, time?: string, box?: string) => {
    if (appointment) {
      setCurrentAppointment(appointment)
      setFormData({
        date: appointment.date,
        time: appointment.time,
        status: appointment.status,
        professionalId: appointment.professionalId.toString(),
        treatmentId: appointment.treatmentId ? appointment.treatmentId.toString() : "",
        clientId: appointment.clientId ? appointment.clientId.toString() : "",
        box: appointment.box,
        deposit: appointment.deposit.toString(),
        price: appointment.price.toString(),
        notes: appointment.notes,
      })
    } else {
      setCurrentAppointment(null)
      resetForm()
      if (time) setFormData((prev) => ({ ...prev, time }))
      if (box) setFormData((prev) => ({ ...prev, box }))
    }
    setIsDialogOpen(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Verificar si el profesional y el tratamiento están disponibles
    const isProfessionalAvailable = availableProfessionals.some((p) => p.id.toString() === formData.professionalId)
    const isTreatmentAvailable = availableTreatments.some((t) => t.id.toString() === formData.treatmentId)

    if (!isProfessionalAvailable || !isTreatmentAvailable) {
      alert("El profesional o el tratamiento seleccionado no está disponible en este horario.")
      return
    }

    const selectedProfessional = professionals.find((p) => p.id.toString() === formData.professionalId)
    const selectedTreatment = formData.treatmentId
      ? treatments.find((t) => t.id.toString() === formData.treatmentId)
      : null
    const selectedClient = formData.clientId ? clients.find((c) => c.id.toString() === formData.clientId) : null

    const appointmentData = {
      date: formData.date,
      time: formData.time,
      status: formData.status as Appointment["status"],
      professionalId: Number.parseInt(formData.professionalId),
      professionalName: selectedProfessional?.name || "",
      treatmentId: formData.treatmentId ? Number.parseInt(formData.treatmentId) : null,
      treatmentName: selectedTreatment?.name || null,
      clientId: formData.clientId ? Number.parseInt(formData.clientId) : null,
      clientName: selectedClient?.name || null,
      box: formData.box,
      deposit: Number.parseInt(formData.deposit) || 0,
      price: Number.parseInt(formData.price) || 0,
      notes: formData.notes,
    }

    if (currentAppointment) {
      // Update existing appointment
      setAppointments(appointments.map((a) => (a.id === currentAppointment.id ? { ...a, ...appointmentData } : a)))
    } else {
      // Add new appointment
      const newId = Math.max(0, ...appointments.map((a) => a.id)) + 1
      setAppointments([
        ...appointments,
        {
          id: newId,
          ...appointmentData,
        },
      ])
    }

    setIsDialogOpen(false)
    resetForm()
  }

  const handleDateChange = (direction: "prev" | "next") => {
    const date = new Date(selectedDate)
    if (direction === "prev") {
      date.setDate(date.getDate() - 1)
    } else {
      date.setDate(date.getDate() + 1)
    }
    setSelectedDate(date.toISOString().split("T")[0])
  }

  const getAppointmentByTimeAndBox = (time: string, box: string) => {
    return appointments.find((a) => a.date === selectedDate && a.time === time && a.box === box)
  }

  const getAvailableTreatments = useCallback(
    (date: string, time: string, box: string) => {
      return treatments.filter((treatment) => {
        if (treatment.isSubtreatment) return false
        return treatment.availability?.some((avail) => {
          const availStart = new Date(`${avail.startDate}T${avail.startTime}`)
          const availEnd = new Date(`${avail.endDate}T${avail.endTime}`)
          const currentDate = new Date(`${date}T${time}`)
          return (
            currentDate >= availStart &&
            currentDate <= availEnd &&
            time >= avail.startTime &&
            time <= avail.endTime &&
            avail.box === box
          )
        })
      })
    },
    [treatments],
  )

  const getCellContent = (time: string, box: string) => {
    const appointment = getAppointmentByTimeAndBox(time, box)
    if (appointment) {
      return getAppointmentContent(appointment)
    }

    const availableTreatments = getAvailableTreatments(selectedDate, time, box)
    if (availableTreatments.length > 0) {
      return (
        <div className="text-xs text-green-600">
          <div className="font-medium">DISPONIBLE</div>
          {availableTreatments.map((treatment) => (
            <div key={treatment.id}>{treatment.name}</div>
          ))}
        </div>
      )
    }

    return <span className="text-xs text-gray-500">No disponible</span>
  }

  const getCellClass = (time: string, box: string) => {
    const appointment = getAppointmentByTimeAndBox(time, box)
    if (!appointment) {
      const availableTreatments = getAvailableTreatments(selectedDate, time, box)
      if (availableTreatments.length > 0) {
        return "bg-green-100 hover:bg-green-200 cursor-pointer"
      }
      return "bg-white hover:bg-gray-50 cursor-pointer"
    }

    switch (appointment.status) {
      case "available":
        return "bg-green-100 hover:bg-green-200 cursor-pointer"
      case "reserved":
        return "bg-orange-100 hover:bg-orange-200 cursor-pointer"
      case "completed":
        return "bg-gray-100 hover:bg-gray-200 cursor-pointer"
      case "cancelled":
        return "bg-red-100 hover:bg-red-200 cursor-pointer"
      default:
        return "bg-white hover:bg-gray-50 cursor-pointer"
    }
  }

  const getAppointmentContent = (appointment: Appointment | undefined) => {
    if (!appointment || appointment.status === "available") {
      return <span className="text-xs text-gray-500">Disponible</span>
    }

    return (
      <div className="text-xs">
        <div className="font-medium">{appointment.treatmentName}</div>
        <div>{appointment.clientName}</div>
        <div className="text-gray-500">{appointment.professionalName}</div>
      </div>
    )
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Agenda</h2>
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="icon" onClick={() => handleDateChange("prev")}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4" />
            <span className="font-medium">
              {new Date(selectedDate).toLocaleDateString("es-AR", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </span>
          </div>
          <Button variant="outline" size="icon" onClick={() => handleDateChange("next")}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="rounded-md border overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr>
              <th className="border-b p-2 text-left font-medium">Hora</th>
              {boxes.map((box) => (
                <th key={box} className="border-b p-2 text-left font-medium">
                  {box}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {timeSlots.map((time) => (
              <tr key={time}>
                <td className="border-b border-r p-2 font-medium">{time}</td>
                {boxes.map((box) => {
                  return (
                    <td
                      key={`${time}-${box}`}
                      className={`border-b border-r p-2 ${getCellClass(time, box)}`}
                      onClick={() => handleOpenDialog(getAppointmentByTimeAndBox(time, box) || null, time, box)}
                    >
                      {getCellContent(time, box)}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{currentAppointment ? "Editar Turno" : "Nuevo Turno"}</DialogTitle>
            <DialogDescription>Complete los datos del turno.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="date">Fecha</Label>
                  <Input
                    id="date"
                    name="date"
                    type="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="time">Hora</Label>
                  <Select value={formData.time} onValueChange={(value) => handleSelectChange("time", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione hora" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="status">Estado</Label>
                <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccione estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">Disponible</SelectItem>
                    <SelectItem value="reserved">Reservado</SelectItem>
                    <SelectItem value="completed">Completado</SelectItem>
                    <SelectItem value="cancelled">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="box">Box</Label>
                <Select value={formData.box} onValueChange={(value) => handleSelectChange("box", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccione box" />
                  </SelectTrigger>
                  <SelectContent>
                    {boxes.map((box) => (
                      <SelectItem key={box} value={box}>
                        {box}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="professionalId">Profesional</Label>
                <Select
                  value={formData.professionalId}
                  onValueChange={(value) => handleSelectChange("professionalId", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccione profesional" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableProfessionals.map((professional) => (
                      <SelectItem key={professional.id} value={professional.id.toString()}>
                        {professional.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="treatmentId">Tratamiento</Label>
                <Select
                  value={formData.treatmentId}
                  onValueChange={(value) => handleSelectChange("treatmentId", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccione tratamiento" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableTreatments.map((treatment) => (
                      <SelectItem key={treatment.id} value={treatment.id.toString()}>
                        {treatment.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="clientId">Cliente</Label>
                <Select value={formData.clientId} onValueChange={(value) => handleSelectChange("clientId", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccione cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="deposit">Seña ($)</Label>
                  <Input
                    id="deposit"
                    name="deposit"
                    type="number"
                    value={formData.deposit}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="price">Precio Total ($)</Label>
                  <Input id="price" name="price" type="number" value={formData.price} onChange={handleInputChange} />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="notes">Observaciones</Label>
                <Textarea id="notes" name="notes" value={formData.notes} onChange={handleInputChange} rows={3} />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit">Guardar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

