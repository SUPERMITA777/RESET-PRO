"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Pencil, Trash2 } from "lucide-react"

// Move this outside of the component and export it
export const initialProfessionals = [
  {
    id: 1,
    name: "María López",
    specialty: "Estética Facial",
    availability: {
      startDate: "2026-03-03",
      endDate: "2026-03-05",
      startTime: "09:00",
      endTime: "18:00",
    },
  },
  {
    id: 2,
    name: "Carlos Rodríguez",
    specialty: "Masajes Terapéuticos",
    availability: {
      startDate: "2026-03-04",
      endDate: "2026-03-06",
      startTime: "10:00",
      endTime: "19:00",
    },
  },
  {
    id: 3,
    name: "Laura Fernández",
    specialty: "Depilación Láser",
    availability: {
      startDate: "2026-03-05",
      endDate: "2026-03-07",
      startTime: "08:00",
      endTime: "17:00",
    },
  },
]

interface Availability {
  startDate: string
  endDate: string
  startTime: string
  endTime: string
}

interface Professional {
  id: number
  name: string
  specialty: string
  availability: Availability
}

export default function ProfessionalsTab() {
  const [professionals, setProfessionals] = useState<Professional[]>(initialProfessionals)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [currentProfessional, setCurrentProfessional] = useState<Professional | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    specialty: "",
    startDate: "",
    endDate: "",
    startTime: "",
    endTime: "",
  })

  useEffect(() => {
    if (currentProfessional) {
      setFormData({
        name: currentProfessional.name,
        specialty: currentProfessional.specialty,
        startDate: currentProfessional.availability.startDate,
        endDate: currentProfessional.availability.endDate,
        startTime: currentProfessional.availability.startTime,
        endTime: currentProfessional.availability.endTime,
      })
    } else {
      setFormData({
        name: "",
        specialty: "",
        startDate: "",
        endDate: "",
        startTime: "",
        endTime: "",
      })
    }
  }, [currentProfessional])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const professionalData = {
      name: formData.name,
      specialty: formData.specialty,
      availability: {
        startDate: formData.startDate,
        endDate: formData.endDate,
        startTime: formData.startTime,
        endTime: formData.endTime,
      },
    }

    if (currentProfessional) {
      // Update existing professional
      setProfessionals(professionals.map((p) => (p.id === currentProfessional.id ? { ...p, ...professionalData } : p)))
    } else {
      // Add new professional
      const newId = Math.max(0, ...professionals.map((p) => p.id)) + 1
      setProfessionals([
        ...professionals,
        {
          id: newId,
          ...professionalData,
        },
      ])
    }

    setIsDialogOpen(false)
    setCurrentProfessional(null)
  }

  const handleEdit = (professional: Professional) => {
    setCurrentProfessional(professional)
    setIsDialogOpen(true)
  }

  const handleDelete = (id: number) => {
    if (confirm("¿Está seguro que desea eliminar este profesional?")) {
      setProfessionals(professionals.filter((p) => p.id !== id))
    }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Profesionales</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setCurrentProfessional(null)} className="flex items-center">
              <Plus className="mr-2 h-4 w-4" />
              Nuevo Profesional
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{currentProfessional ? "Editar Profesional" : "Nuevo Profesional"}</DialogTitle>
              <DialogDescription>Complete los datos del profesional y su disponibilidad.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Nombre</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="specialty">Especialidad</Label>
                  <Input
                    id="specialty"
                    name="specialty"
                    value={formData.specialty}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="startDate">Fecha de inicio</Label>
                    <Input
                      id="startDate"
                      name="startDate"
                      type="date"
                      value={formData.startDate}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="endDate">Fecha de fin</Label>
                    <Input
                      id="endDate"
                      name="endDate"
                      type="date"
                      value={formData.endDate}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="startTime">Hora de inicio</Label>
                    <Input
                      id="startTime"
                      name="startTime"
                      type="time"
                      value={formData.startTime}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="endTime">Hora de fin</Label>
                    <Input
                      id="endTime"
                      name="endTime"
                      type="time"
                      value={formData.endTime}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Guardar</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Nombre</TableHead>
              <TableHead>Especialidad</TableHead>
              <TableHead className="hidden md:table-cell">Disponibilidad</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {professionals.map((professional) => (
              <TableRow key={professional.id}>
                <TableCell>{professional.id}</TableCell>
                <TableCell>{professional.name}</TableCell>
                <TableCell>{professional.specialty}</TableCell>
                <TableCell className="hidden md:table-cell">
                  {`${professional.availability.startDate} al ${professional.availability.endDate}, 
                    ${professional.availability.startTime} - ${professional.availability.endTime}`}
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => handleEdit(professional)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(professional.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {professionals.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-4">
                  No hay profesionales registrados
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

