"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { LogOut, Users, Scissors, Calendar, CalendarDays, User, ShoppingBag, DollarSign } from "lucide-react"
import StatsCards from "@/components/stats-cards"
import ProfessionalsTab from "@/components/tabs/professionals-tab"
import TreatmentsTab from "@/components/tabs/treatments-tab"
import AppointmentsTab from "@/components/tabs/appointments-tab"
import AgendaTab from "@/components/tabs/agenda-tab"
import ClientsTab from "@/components/tabs/clients-tab"
import ProductsTab from "@/components/tabs/products-tab"
import SalesTab from "@/components/tabs/sales-tab"

interface DashboardProps {
  onLogout: () => void
}

export default function Dashboard({ onLogout }: DashboardProps) {
  const [activeTab, setActiveTab] = useState("agenda")

  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-bold">RESET-SOFT</h1>
            <span className="ml-4 text-sm text-muted-foreground">Panel de Administración</span>
          </div>
          <Button variant="ghost" size="sm" onClick={onLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Cerrar Sesión
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <StatsCards />

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
          <TabsList className="grid grid-cols-7 mb-6">
            <TabsTrigger value="professionals" className="flex items-center">
              <Users className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Profesionales</span>
            </TabsTrigger>
            <TabsTrigger value="treatments" className="flex items-center">
              <Scissors className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Tratamientos</span>
            </TabsTrigger>
            <TabsTrigger value="appointments" className="flex items-center">
              <Calendar className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Turnos</span>
            </TabsTrigger>
            <TabsTrigger value="agenda" className="flex items-center">
              <CalendarDays className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Agenda</span>
            </TabsTrigger>
            <TabsTrigger value="clients" className="flex items-center">
              <User className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Clientes</span>
            </TabsTrigger>
            <TabsTrigger value="products" className="flex items-center">
              <ShoppingBag className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Productos</span>
            </TabsTrigger>
            <TabsTrigger value="sales" className="flex items-center">
              <DollarSign className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Ventas</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="professionals">
            <ProfessionalsTab />
          </TabsContent>
          <TabsContent value="treatments">
            <TreatmentsTab />
          </TabsContent>
          <TabsContent value="appointments">
            <AppointmentsTab />
          </TabsContent>
          <TabsContent value="agenda">
            <AgendaTab />
          </TabsContent>
          <TabsContent value="clients">
            <ClientsTab />
          </TabsContent>
          <TabsContent value="products">
            <ProductsTab />
          </TabsContent>
          <TabsContent value="sales">
            <SalesTab />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="bg-white border-t py-4">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} RESET-SOFT - Sistema de Gestión de Centro de Estética
        </div>
      </footer>
    </div>
  )
}

