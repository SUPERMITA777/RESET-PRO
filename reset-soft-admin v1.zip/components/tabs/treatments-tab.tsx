"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Pencil, Trash2, ChevronDown, ChevronRight } from "lucide-react"

interface Availability {
  id?: number
  startDate: string
  endDate: string
  startTime: string
  endTime: string
  box: string
}

interface Treatment {
  id: number
  name: string
  description: string
  duration: number
  price: number
  isSubtreatment: boolean
  parentId: number | null
  availability: Availability[] | null
}

export default function TreatmentsTab() {
  const [treatments, setTreatments] = useState<Treatment[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [currentTreatment, setCurrentTreatment] = useState<Treatment | null>(null)
  const [expandedTreatments, setExpandedTreatments] = useState<number[]>([])
  const [availabilities, setAvailabilities] = useState<Availability[]>([])
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    duration: "",
    price: "",
    isSubtreatment: "false",
    parentId: "",
  })

  useEffect(() => {
    fetchTreatments()
  }, [])

  const fetchTreatments = async () => {
    const response = await fetch("/api/treatments")
    const data = await response.json()
    setTreatments(data)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData({ ...formData, [name]: value })
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      duration: "",
      price: "",
      isSubtreatment: "false",
      parentId: "",
    })
    setAvailabilities([])
  }

  const handleOpenDialog = (treatment: Treatment | null = null) => {
    if (treatment) {
      setCurrentTreatment(treatment)
      setFormData({
        name: treatment.name,
        description: treatment.description,
        duration: treatment.duration.toString(),
        price: treatment.price.toString(),
        isSubtreatment: treatment.isSubtreatment.toString(),
        parentId: treatment.parentId ? treatment.parentId.toString() : "",
      })
      setAvailabilities(treatment.availability || [])
    } else {
      setCurrentTreatment(null)
      resetForm()
    }
    setIsDialogOpen(true)
  }

  const handleAddAvailability = () => {
    const currentYear = new Date().getFullYear()
    setAvailabilities([
      ...availabilities,
      {
        startDate: `${currentYear}-01-01`,
        endDate: `${currentYear}-12-31`,
        startTime: "09:00",
        endTime: "17:00",
        box: "Box 1",
      },
    ])
  }

  const handleAvailabilityChange = (index: number, field: keyof Availability, value: string) => {
    const newAvailabilities = [...availabilities]
    newAvailabilities[index][field] = value
    setAvailabilities(newAvailabilities)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const treatmentData = {
      id: currentTreatment?.id,
      name: formData.name,
      description: formData.description,
      duration: Number.parseInt(formData.duration) || 0,
      price: Number.parseFloat(formData.price) || 0,
      isSubtreatment: formData.isSubtreatment === "true",
      parentId: formData.isSubtreatment === "true" && formData.parentId ? Number.parseInt(formData.parentId) : null,
      availability: formData.isSubtreatment === "false" ? availabilities : null,
    }

    const response = await fetch("/api/treatments", {
      method: currentTreatment ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(treatmentData),
    })

    if (response.ok) {
      fetchTreatments()
      setIsDialogOpen(false)
      resetForm()
    } else {
      console.error("Error al guardar el tratamiento")
    }
  }

  const handleDelete = async (id: number) => {
    if (confirm("¿Está seguro que desea eliminar este tratamiento?")) {
      const response = await fetch(`/api/treatments/${id}`, { method: "DELETE" })
      if (response.ok) {
        fetchTreatments()
      } else {
        console.error("Error al eliminar el tratamiento")
      }
    }
  }

  const toggleExpand = (id: number) => {
    if (expandedTreatments.includes(id)) {
      setExpandedTreatments(expandedTreatments.filter((t) => t !== id))
    } else {
      setExpandedTreatments([...expandedTreatments, id])
    }
  }

  // Get main treatments (not subtratments)
  const mainTreatments = treatments.filter((t) => !t.isSubtreatment)

  // Get parent treatments for select dropdown
  const parentTreatmentOptions = treatments.filter((t) => !t.isSubtreatment)

  const boxes = ["Box 1", "Box 2", "Box 3", "Box 4", "Box 5"]

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Tratamientos</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()} className="flex items-center">
              <Plus className="mr-2 h-4 w-4" />
              Nuevo Tratamiento
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {currentTreatment
                  ? currentTreatment.isSubtreatment
                    ? "Editar Subtratamiento"
                    : "Editar Familia de Tratamientos"
                  : formData.isSubtreatment === "true"
                    ? "Nuevo Subtratamiento"
                    : "Nueva Familia de Tratamientos"}
              </DialogTitle>
              <DialogDescription>Complete los datos del tratamiento.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Nombre</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="isSubtreatment">Tipo de Tratamiento</Label>
                  <Select
                    value={formData.isSubtreatment}
                    onValueChange={(value) => handleSelectChange("isSubtreatment", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="false">Familia de Tratamientos</SelectItem>
                      <SelectItem value="true">Subtratamiento</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {formData.isSubtreatment === "true" && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="duration">Duración (minutos)</Label>
                        <Input
                          id="duration"
                          name="duration"
                          type="number"
                          value={formData.duration}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="price">Precio ($)</Label>
                        <Input
                          id="price"
                          name="price"
                          type="number"
                          value={formData.price}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="parentId">Tratamiento Principal</Label>
                      <Select
                        value={formData.parentId}
                        onValueChange={(value) => handleSelectChange("parentId", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccione tratamiento principal" />
                        </SelectTrigger>
                        <SelectContent>
                          {parentTreatmentOptions.map((treatment) => (
                            <SelectItem key={treatment.id} value={treatment.id.toString()}>
                              {treatment.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}
                {formData.isSubtreatment === "false" && (
                  <div className="grid gap-4">
                    <Label>Disponibilidad</Label>
                    {availabilities.map((availability, index) => (
                      <div key={index} className="grid grid-cols-5 gap-2">
                        <Input
                          type="date"
                          value={availability.startDate}
                          onChange={(e) => handleAvailabilityChange(index, "startDate", e.target.value)}
                          placeholder="Fecha inicio"
                        />
                        <Input
                          type="date"
                          value={availability.endDate}
                          onChange={(e) => handleAvailabilityChange(index, "endDate", e.target.value)}
                          placeholder="Fecha fin"
                        />
                        <Input
                          type="time"
                          value={availability.startTime}
                          onChange={(e) => handleAvailabilityChange(index, "startTime", e.target.value)}
                          placeholder="Hora inicio"
                        />
                        <Input
                          type="time"
                          value={availability.endTime}
                          onChange={(e) => handleAvailabilityChange(index, "endTime", e.target.value)}
                          placeholder="Hora fin"
                        />
                        <Select
                          value={availability.box}
                          onValueChange={(value) => handleAvailabilityChange(index, "box", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccione box" />
                          </SelectTrigger>
                          <SelectContent>
                            {boxes.map((box) => (
                              <SelectItem key={box} value={box}>
                                {box}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    ))}
                    <Button type="button" onClick={handleAddAvailability}>
                      Agregar disponibilidad
                    </Button>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button type="submit">Guardar</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50px]"></TableHead>
              <TableHead>Nombre</TableHead>
              <TableHead className="hidden md:table-cell">Descripción</TableHead>
              <TableHead>Duración</TableHead>
              <TableHead>Precio</TableHead>
              <TableHead className="hidden md:table-cell">Disponibilidad</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mainTreatments.map((treatment) => (
              <>
                <TableRow key={treatment.id} className="bg-muted/30">
                  <TableCell>
                    {treatments.some((t) => t.parentId === treatment.id) && (
                      <Button variant="ghost" size="icon" onClick={() => toggleExpand(treatment.id)}>
                        {expandedTreatments.includes(treatment.id) ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                      </Button>
                    )}
                  </TableCell>
                  <TableCell className="font-medium">{treatment.name}</TableCell>
                  <TableCell className="hidden md:table-cell">{treatment.description}</TableCell>
                  <TableCell>-</TableCell>
                  <TableCell>-</TableCell>
                  <TableCell className="hidden md:table-cell">
                    {treatment.availability?.map((avail, index) => (
                      <div key={index}>
                        {avail.startDate} - {avail.endDate}, {avail.startTime} - {avail.endTime}, {avail.box}
                      </div>
                    ))}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(treatment)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(treatment.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
                {expandedTreatments.includes(treatment.id) &&
                  treatments
                    .filter((t) => t.parentId === treatment.id)
                    .map((subtreatment) => (
                      <TableRow key={subtreatment.id} className="bg-white">
                        <TableCell></TableCell>
                        <TableCell className="pl-8">└ {subtreatment.name}</TableCell>
                        <TableCell className="hidden md:table-cell">{subtreatment.description}</TableCell>
                        <TableCell>{subtreatment.duration} min</TableCell>
                        <TableCell>${subtreatment.price.toLocaleString("es-AR")}</TableCell>
                        <TableCell className="hidden md:table-cell">-</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(subtreatment)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(subtreatment.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
              </>
            ))}
            {mainTreatments.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-4">
                  No hay tratamientos registrados
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

