"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Plus, Pencil, Trash2 } from "lucide-react"

// Mock data
const initialAppointments = [
  {
    id: 1,
    date: "2025-03-03",
    time: "10:00",
    status: "reserved",
    professionalId: 1,
    professionalName: "María López",
    treatmentId: 2,
    treatmentName: "Limpieza Facial Profunda",
    clientId: 1,
    clientName: "Ana García",
    box: "Box 1",
  },
  {
    id: 2,
    date: "2025-03-03",
    time: "11:30",
    status: "completed",
    professionalId: 2,
    professionalName: "Carlos Rodríguez",
    treatmentId: 7,
    treatmentName: "Masaje Corporal Completo",
    clientId: 2,
    clientName: "Juan Pérez",
    box: "Box 2",
  },
  {
    id: 3,
    date: "2025-03-04",
    time: "09:00",
    status: "available",
    professionalId: 3,
    professionalName: "Laura Fernández",
    treatmentId: null,
    treatmentName: null,
    clientId: null,
    clientName: null,
    box: "Box 3",
  },
  {
    id: 4,
    date: "2025-03-04",
    time: "15:00",
    status: "cancelled",
    professionalId: 1,
    professionalName: "María López",
    treatmentId: 5,
    treatmentName: "Masaje de Espalda",
    clientId: 3,
    clientName: "Sofía Martínez",
    box: "Box 1",
  },
]

// Mock data for dropdowns
const professionals = [
  { id: 1, name: "María López" },
  { id: 2, name: "Carlos Rodríguez" },
  { id: 3, name: "Laura Fernández" },
]

const treatments = [
  { id: 2, name: "Limpieza Facial Profunda" },
  { id: 3, name: "Limpieza Facial Express" },
  { id: 5, name: "Masaje de Espalda" },
  { id: 6, name: "Masaje de Cuello" },
  { id: 7, name: "Masaje Corporal Completo" },
]

const clients = [
  { id: 1, name: "Ana García" },
  { id: 2, name: "Juan Pérez" },
  { id: 3, name: "Sofía Martínez" },
]

const boxes = ["Box 1", "Box 2", "Box 3", "Box 4", "Box 5"]

interface Appointment {
  id: number
  date: string
  time: string
  status: "available" | "reserved" | "completed" | "cancelled"
  professionalId: number
  professionalName: string
  treatmentId: number | null
  treatmentName: string | null
  clientId: number | null
  clientName: string | null
  box: string
}

export default function AppointmentsTab() {
  const [appointments, setAppointments] = useState<Appointment[]>(initialAppointments)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [currentAppointment, setCurrentAppointment] = useState<Appointment | null>(null)
  const [formData, setFormData] = useState({
    date: "",
    time: "",
    status: "",
    professionalId: "",
    treatmentId: "",
    clientId: "",
    box: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData({ ...formData, [name]: value })
  }

  const resetForm = () => {
    const today = new Date().toISOString().split("T")[0]
    setFormData({
      date: today,
      time: "09:00",
      status: "available",
      professionalId: "",
      treatmentId: "",
      clientId: "",
      box: "Box 1",
    })
  }

  const handleOpenDialog = (appointment: Appointment | null = null) => {
    if (appointment) {
      setCurrentAppointment(appointment)
      setFormData({
        date: appointment.date,
        time: appointment.time,
        status: appointment.status,
        professionalId: appointment.professionalId.toString(),
        treatmentId: appointment.treatmentId ? appointment.treatmentId.toString() : "",
        clientId: appointment.clientId ? appointment.clientId.toString() : "",
        box: appointment.box,
      })
    } else {
      setCurrentAppointment(null)
      resetForm()
    }
    setIsDialogOpen(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const selectedProfessional = professionals.find((p) => p.id.toString() === formData.professionalId)
    const selectedTreatment = formData.treatmentId
      ? treatments.find((t) => t.id.toString() === formData.treatmentId)
      : null
    const selectedClient = formData.clientId ? clients.find((c) => c.id.toString() === formData.clientId) : null

    const appointmentData = {
      date: formData.date,
      time: formData.time,
      status: formData.status as Appointment["status"],
      professionalId: Number.parseInt(formData.professionalId),
      professionalName: selectedProfessional?.name || "",
      treatmentId: formData.treatmentId ? Number.parseInt(formData.treatmentId) : null,
      treatmentName: selectedTreatment?.name || null,
      clientId: formData.clientId ? Number.parseInt(formData.clientId) : null,
      clientName: selectedClient?.name || null,
      box: formData.box,
    }

    if (currentAppointment) {
      // Update existing appointment
      setAppointments(appointments.map((a) => (a.id === currentAppointment.id ? { ...a, ...appointmentData } : a)))
    } else {
      // Add new appointment
      const newId = Math.max(0, ...appointments.map((a) => a.id)) + 1
      setAppointments([
        ...appointments,
        {
          id: newId,
          ...appointmentData,
        },
      ])
    }

    setIsDialogOpen(false)
    resetForm()
  }

  const handleDelete = (id: number) => {
    if (confirm("¿Está seguro que desea eliminar este turno?")) {
      setAppointments(appointments.filter((a) => a.id !== id))
    }
  }

  const getStatusBadge = (status: Appointment["status"]) => {
    switch (status) {
      case "available":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800">
            Disponible
          </Badge>
        )
      case "reserved":
        return (
          <Badge variant="outline" className="bg-orange-100 text-orange-800">
            Reservado
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800">
            Completado
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800">
            Cancelado
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Turnos</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()} className="flex items-center">
              <Plus className="mr-2 h-4 w-4" />
              Nuevo Turno
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{currentAppointment ? "Editar Turno" : "Nuevo Turno"}</DialogTitle>
              <DialogDescription>Complete los datos del turno.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="date">Fecha</Label>
                    <Input
                      id="date"
                      name="date"
                      type="date"
                      value={formData.date}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="time">Hora</Label>
                    <Input
                      id="time"
                      name="time"
                      type="time"
                      value={formData.time}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="status">Estado</Label>
                  <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Disponible</SelectItem>
                      <SelectItem value="reserved">Reservado</SelectItem>
                      <SelectItem value="completed">Completado</SelectItem>
                      <SelectItem value="cancelled">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="professionalId">Profesional</Label>
                  <Select
                    value={formData.professionalId}
                    onValueChange={(value) => handleSelectChange("professionalId", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione profesional" />
                    </SelectTrigger>
                    <SelectContent>
                      {professionals.map((professional) => (
                        <SelectItem key={professional.id} value={professional.id.toString()}>
                          {professional.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="treatmentId">Tratamiento</Label>
                  <Select
                    value={formData.treatmentId}
                    onValueChange={(value) => handleSelectChange("treatmentId", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione tratamiento" />
                    </SelectTrigger>
                    <SelectContent>
                      {treatments.map((treatment) => (
                        <SelectItem key={treatment.id} value={treatment.id.toString()}>
                          {treatment.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="clientId">Cliente</Label>
                  <Select value={formData.clientId} onValueChange={(value) => handleSelectChange("clientId", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione cliente" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients.map((client) => (
                        <SelectItem key={client.id} value={client.id.toString()}>
                          {client.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="box">Box</Label>
                  <Select value={formData.box} onValueChange={(value) => handleSelectChange("box", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione box" />
                    </SelectTrigger>
                    <SelectContent>
                      {boxes.map((box) => (
                        <SelectItem key={box} value={box}>
                          {box}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Guardar</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Fecha</TableHead>
              <TableHead>Hora</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="hidden md:table-cell">Profesional</TableHead>
              <TableHead className="hidden md:table-cell">Tratamiento</TableHead>
              <TableHead className="hidden md:table-cell">Cliente</TableHead>
              <TableHead>Box</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {appointments.map((appointment) => (
              <TableRow key={appointment.id}>
                <TableCell>{appointment.id}</TableCell>
                <TableCell>{new Date(appointment.date).toLocaleDateString("es-AR")}</TableCell>
                <TableCell>{appointment.time}</TableCell>
                <TableCell>{getStatusBadge(appointment.status)}</TableCell>
                <TableCell className="hidden md:table-cell">{appointment.professionalName}</TableCell>
                <TableCell className="hidden md:table-cell">{appointment.treatmentName || "-"}</TableCell>
                <TableCell className="hidden md:table-cell">{appointment.clientName || "-"}</TableCell>
                <TableCell>{appointment.box}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(appointment)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(appointment.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {appointments.length === 0 && (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-4">
                  No hay turnos registrados
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

